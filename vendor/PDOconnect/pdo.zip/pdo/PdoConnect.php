<?php
class pdoRequest{
    private $host = 'localhost';
    private $port = '3306';
    private $dbname = 'test';
    private $username = 'markandr';
    private $password = '';
    private $table = null;
    private $conn;

    public function getHost(){
        return $this->host;
    }

    public function setHost($host){
        $this->host = $host;
    }

    public function getPort(){
        return $this->port;
    }

    public function setPort($port){
        $this->port = $port;
    }

    public function getDbname(){
        return $this->dbname;
    }

    public function setDbname($dbname){
        $this->dbname = $dbname;
    }

    public function getUsername(){
        return $this->username;
    }

    public function setUsername($username){
        $this->username = $username;
    }

    public function getPassword(){
        return $this->password;
    }

    public function setPassword($password){
        $this->password = $password;
    }

    public function getTable(){
        return $this->table;
    }

    public function setTable($table){
        $this->table = $table;
    }

    public function setConnect($conn){
        $this->conn = $conn;
    }

    public function __construct($config = []){
        if(count($config) > 0){
            $this->setConfig($config);
        }
        $this->connect();
    }

    private function setConfig($config){
        if(isset($config['host']))
            $this->setHost($config['host']);
        if(isset($config['port']))
            $this->setPort($config['port']);
        if(isset($config['username']))
            $this->setUsername($config['username']);
        if(isset($config['password']))
            $this->setPassword($config['password']);
        if(isset($config['dbname']))
            $this->setDbname($config['dbname']);
        if(isset($config['table']))
            $this->setTable($config['table']);
    }

    private function connect(){
        try {
            $query_pdo = "mysql:host=" . $this->getHost() . ";dbname=" . $this->getDbname() . ";port=" . $this->getPort();
            $conn = new PDO($query_pdo,$this->getUsername(),$this->getPassword());
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->setConnect($conn);
            return true;
        }
        catch(PDOException $e){
            return false;
        }
    }

    public function count(){
        $sql = 'SELECT COUNT(id) FROM ' . $this->getTable();
        try{
            $result = $this->conn->prepare($sql);
            $result->execute();
            $result = $result->fetchAll();
            return $result[0][0];
        }catch (PDOException $e){
            return false;
        }
    }

    public function all($select = [], $limit = null){
        $sl = count($select) > 0 ? implode(' ,', $select) : '*';
        $sql = "SELECT " . $sl . " FROM " . $this->getTable();
        if($limit != null){
            if(gettype($limit) == 'string')
                $sql .= " limit " . $limit;
            else if(gettype($limit) == 'array')
                $sql .= " limit " . implode(', ', $limit);
        }
        try{
            $result = $this->conn->prepare($sql);
            $result->execute();
            $result = $result->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        }catch (PDOException $e){
            return false;
        }
    }

    public function get($where, $limit = null){
        $_where  = $this->_buildWhere($where);
        $sql = "SELECT * FROM " . $this->getTable() . " where " . $_where;
        if($limit != null) $sql .= ' limit '. $limit;
        try{
            $result = $this->conn->prepare($sql);
            $result->execute();
            $result = $result->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        }catch (PDOException $e){
            return false;
        }
    }

    public function one($where){
        return $this->get($where) != null ? ($this->get($where))[0] : null;
    }

    public function getPage($page, $limit){
        return $this->all(['*'], [(int) $page * (int) $limit - (int) $limit, $limit]);
    }

    private function _buildWhere($where){
        if(count($where) == 0){
            return '';
        }
        $w = ' id >= 0 ';
        if(gettype($where[0]) != 'array'){
            $w .= " AND ";
            if(count($where) == 3){
                $w .= $where[0] . ' ' . $where[1] . ' "'. $where[2] . '"';
            }
            else{
                $w .= $where[0] . ' = "' . $where[1] . '"';
            }
            return $w;
        }
        foreach ($where as $item=>$value){
            $w .= ' AND ';
            if(count($value) == 3){
                $w .= $value[0] . ' ' . $value[1] . ' '. $value[2];
            }
            else{
                $w .= $value[0] . ' = ' . $value[1];
            }
        }
        return $w;
    }

    public function insert($arr, $duplicate = null, $update = false){
        if($duplicate != null){
            if($this->one([$duplicate, $arr[$duplicate]]) != null){
                if($update){
                    return $this->update($arr, [$duplicate, $arr[$duplicate]]);
                }
                else return false;
            }
        }
        $keys = array_keys($arr);
        $values = array_values($arr);
        $col_insert = implode(', ', $keys);
        $val_insert = array_reduce($values, function ($a, $b){
            if($a == '') return "'" . $b . "'";
            return $a . ", '" . $b;
        });
        $val_insert .= "'";
        try{
            $sql = "INSERT INTO " . $this->getTable() . " (" . $col_insert . ") VALUES" . " (" . $val_insert . ")";
            $this->conn->exec($sql);
            return true;
        }catch (PDOException $e){
            return false;
        }
    }

    public function update($arr, $where){
        if(isset($arr[$where[0]])) unset($arr[$where[0]]);
        $w = $where[0] . ' = "' . $where[1] . '"';
        $count_arr = count($arr);
        $i = 0;
        $sql = "UPDATE " . $this->getTable() . " SET ";
        foreach ($arr as $item => $value){
            $sql .= $item . ' = "' . $value . '"';
            if($i < ($count_arr - 1)){
                $sql .= ', ';
            }
            $i++;
        }
        $sql .= ' WHERE ' . $w;
        try{
            $this->conn->exec($sql);
            return true;
        }catch (PDOException $e){
            return false;
        }
    }

    public function delete($where, $exc = '='){
        $w = ' ' .  $where[0] . ' ' . $exc . ' ' . $where[1];
        $sql = 'DELETE FROM ' . $this->getTable() . ' WHERE ' . $w;
        try{
            $this->conn->exec($sql);
            return true;
        }catch (PDOException $e){
            return false;
        }
    }

}